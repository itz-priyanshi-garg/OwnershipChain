<!DOCTYPE html>
<html lang="en">
<head>
  <title>Bootstrap Example</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/js/bootstrap.min.js"></script>
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
</head>
<script src="jsfiles/smartcontract.js"></script>
<script>

window.onload=function(){
      if(typeof web3!='undefined'){
                var web3=new Web3(web3.currentProvider);
            }else{
               var web3=new Web3(new Web3.providers.HttpProvider("http://localhost:7545"));
            }
            web3.eth.defaultAccount=web3.eth.accounts[0];
            //alert(web3.eth.accounts[0]);
            var sc=web3.eth.contract(ABI);
            var tc=sc.at(address);
            user = tc.getUserDetails();
            document.getElementById("display").innerHTML="Welcome "+user[0];
          }
   $(document).ready(function(){
        $("#addon").click(function(){
          var type = $("#type").val();
          var amount = $("#amount").val();
          var bill = $("#bill").val();
          var product = $("#product").val();
          if(typeof web3!='undefined'){
                var web3=new Web3(web3.currentProvider);
            }else{
               var web3=new Web3(new Web3.providers.HttpProvider("http://localhost:7545"));
            }
           // alert("Proceeding...")
            web3.eth.defaultAccount=web3.eth.accounts[0];
            var sc=web3.eth.contract(ABI);
            var tc=sc.at(address);
            tc.addBill(type,amount,bill,product,{from: web3.eth.accounts[0], gas: 200000});
            alert("Bill added successfully");
        });
        })
</script>

<body style="background-color: black;">

  <nav class="navbar navbar-inverse">
    <div class="container-fluid">
      
      <ul class="nav navbar-nav">
        <li class="active"><a href="ProfilePage.php">My Profile</a></li>
      </ul>
      <ul class="nav navbar-nav navbar-right">
        <li><a href="mailto: priyanshi.18bcs1068@abes.ac.in">Contact Us </a></li>
        <li>
          <div class="navbar-header">
            <a class="navbar-brand" href="index.php">Home Page</a>
          </div>
        </li>
      </ul>
    </div>
  </nav> 
  
<div class="container" style="text-align: center;">
  <div class="row" style="background-color: rgb(31, 31, 31);padding-bottom: 15px;">
    <div class="col-lg-5">
      <h2 style="float: right;color: cadetblue;width: 85%;background-image:linear-gradient(to right, rgb(31, 31, 31) , rgb(61, 61, 61));padding: 7px 1px;"><i class="fa fa-gear" style="font-size:42px;padding-right:5%;"></i>OWNERSHIP CHAIN</h2>
    </div>
    <div class="col-lg-7">
      <h2 style="float: right;color: cadetblue;font-size: 30px;margin-top: 30px;">Secure the ownership of your products</h2>
    </div>
  </div>
  <div class="row" style="padding-bottom: 15px;margin-top: 2%;">
    <div class="col-lg-4" style="background-color: rgb(31, 31, 31);padding-bottom: 7px;">
      <h2 style="color: rgb(199, 198, 196);" id="display"></h2>
    </div>
  </div>
  <div class="row" style="padding-bottom: 15px;margin-top: 1%;">
    <div class="col-lg-6" style="background-color: rgb(31, 31, 31);">
      <h1 style="text-align: left; font-size: 45px;color: rgb(199, 198, 196);font-weight: 400;padding-bottom: 60px;padding-right: 13%;">If you make an ownership of your actions, you have already won.</h1>
    </div>
    <div class="col-lg-6">
      <button class="btn btn-primary" style="margin-bottom: 5%;">Add new bill</button><br>

      <label for="fname" style="margin-bottom: 3%;"><h4 style="color:darkgrey"><b>Type of bill:</b></h4></label>
      <input type="text" id="type" name="fname" style="background-color:ghostwhite;border-color:rgb(32, 32, 32) ;"><br>
      <label for="fname" style="margin-bottom: 3%;"><h4 style="color:darkgrey"><b>Amount paid:</b></h4></label>
      <input type="text" id="amount" name="fname" style="background-color:ghostwhite;border-color:rgb(32, 32, 32) ;"><br>
      <label for="fname" style="margin-bottom: 3%;"><h4 style="color:darkgrey"><b>Image of bill:</b></h4></label>
      <input type="text" id="bill" name="fname" style="background-color:ghostwhite;border-color:rgb(32, 32, 32) ;"><br>
      <label for="fname" style="margin-bottom: 7%;"><h4 style="color:darkgrey"><b>Image of product :</b></h4></label>
      <input type="text" id="product" name="fname" style="background-color: ghostwhite;border-color:rgb(32, 32, 32) ;"><br>

      <button class="btn btn-primary" id="addon">Proceed</button>
    </div>
  </div>
</div>
<script>
  function myFunction() {
    alert("Bill added successfully!!");
  }
  </script>
<div class="footer" style="text-align: center;position:fixed;bottom: 0;background-color: rgb(31, 31, 31);color: rgb(199, 198, 196)">
  <h5 style="padding: 10px 40px;padding-bottom: 0;">This website basically aims for securing the ownership of the products by saving bills. You can save your bills in the form of image and also upload the picture of your product purchased. The data for the bill that is once saved can never be changed. You can change the profile data but you cannot change the data provided after saving the bill.</h5>
  <h5>Join us: <i class="fa fa-instagram" style="font-size:24px; color:rgb(156, 19, 133);"></i> <i class="fa fa-twitter" style="font-size:24px;color:rgb(47, 75, 201);"></i></h5>
</div>
</body>
</html>
