<!DOCTYPE html>
<html lang="en">
<head>
  <title>Bootstrap Example</title>
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/js/bootstrap.min.js"></script>
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
  <link rel="manifest" href="manifest.json">
<script src="sw.js"></script>
</head>
<body style="background-color: black;">

  <header>
    <nav class="navbar navbar-expand-sm bg-dark navbar-dark">
      
        <!-- Links -->
        <ul class="navbar-nav">
          
          <li class="nav-item">
            <a class="nav-link" href="mailto: priyanshi.18bcs1068@abes.ac.in" style="position: relative; left:1100px">Contact us</a>
          </li>

          <li class="nav-item">
            <a class="nav-link" href="welcome.php" style="position: relative; left:1200px">Home Screen</a>
          </li>
        </ul>
      </nav>
</header>

<div class="container" style="background-color: black;">
  <div class="container" style="background-color: black;">
  <img src="images/tt.jpg" width=100% style="position:relative; left:-30px;" height=400></div>
</div>

<div class="container" style="background-color: black;">
  <div class="container" style="background-color: black;">
  <img src="images/welcome.PNG" width=100% style="position:relative; left:-30px;" height=150></div>
</div>
<br>
<br>
<div class="container" style="background-color: black;">
  <div class="fluid-container" style="background-color: black;">
  <img src="images/Capture.PNG" width=100% style="position:relative; left:-30px;" height=150></div>
</div>
<br><br>
<a href="signup.php"><button" class="btn btn-secondary btn-lg" style="background-color:gray; position: relative;left:650px"><b>Join Now</b></button></a>

<br>
<section>
  <div class="row" class="container">
      <div class="col-lg-12" style="color:white; text-align: center;">This website basically aims for securing the ownership of the products by saving bills. You can save your bills in the form of image and also upload the picture of your product purchased. The data for the bill that is once saved can never be changed. You can change the profile data but you cannot change the data provided after saving the bill.</h5>
          <h5>Join us: <i class="fa fa-instagram" style="font-size:24px; color:rgb(156, 19, 133);"></i> <i class="fa fa-twitter" style="font-size:24px;color:rgb(47, 75, 201);"></i></div>
  </div>
</section>
<script>
        if('serviceWorker' in navigator) {
    navigator.serviceWorker.register('sw.js').then(function(registration) {
        console.log('Service Worker Registered');
    });

} else console.log('Your browser does not support the Service-Worker!');
        </script>

</body>
</html>
