<!DOCTYPE html>
<html>
<!-- Latest compiled and minified CSS -->
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.0/css/bootstrap.min.css">

<!-- jQuery library -->
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>

<!-- Popper JS -->
<script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.16.0/umd/popper.min.js"></script>

<!-- Latest compiled JavaScript -->
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.0/js/bootstrap.min.js"></script>
<script src="jsfiles/smartcontract.js"></script>
<script>
    window.onload=function(){
      if(typeof web3!='undefined'){
                var web3=new Web3(web3.currentProvider);
            }else{
               var web3=new Web3(new Web3.providers.HttpProvider("http://localhost:7545"));
            }
            web3.eth.defaultAccount=web3.eth.accounts[0];
            //alert(web3.eth.accounts[0]);
            var sc=web3.eth.contract(ABI);
            var tc=sc.at(address);
            user = tc.getUserDetails();
            document.getElementById("name1").innerHTML ="Welcome "+user[0];
            document.getElementById("name").innerHTML = "Name : "+user[0];
            document.getElementById("email").innerHTML = "Email : "+user[1];
            document.getElementById("mobile").innerHTML = "Mobile : "+user[2];
            document.getElementById("pass").innerHTML = user[3];
            //console.log(user[0]);
    }
</script>
<script>
    $(document).ready(function(){
        $("#view").click(function(){
          
          if(typeof web3!='undefined'){
                var web3=new Web3(web3.currentProvider);
            }else{
               var web3=new Web3(new Web3.providers.HttpProvider("http://localhost:7545"));
            }
            web3.eth.defaultAccount=web3.eth.accounts[0];
            var sc=web3.eth.contract(ABI);
            var tc=sc.at(address);
           //console.log(tc);
            var status = tc.getbill();
            alert("We're gonna fetch you the details of recently added bill");
            alert("Type of bill : "+status[0]+"\nAmount paid : Rs."+status[1]);
            window.location.href="viewbill.php";
        });
    })
</script>

    <body style="background-color: black;">
        <header>
            <nav class="navbar navbar-expand-sm bg-dark navbar-dark">
              
                <!-- Links -->
                <ul class="navbar-nav">
                  
                  <li class="nav-item">
                    <a class="nav-link" href="mailto: priyanshi.18bcs1068@abes.ac.in" style="position: relative; left:1100px">Contact us</a>
                  </li>

                  <li class="nav-item">
                    <a class="nav-link" href="index.php" style="position: relative; left:1200px">Home Screen</a>
                  </li>
                </ul>
              </nav>
              
        </header>
        <div class="container" style="background-color: black;">
            <div class="fluid-container" style="background-color: black;">
            <img src="images/Capture.PNG" width=100% style="position:relative; left:-30px;"></div>
        </div>

        <section style="padding-bottom: 15px;">
            <div class="row" style="padding-bottom: 20px;margin-top: 2%;">
                <div class="col-lg-1"></div>
                <div class="col-lg-5" style="background-color: rgb(31, 31, 31);padding-bottom: 7px;position: relative;left:70px">
                  <h1 style="color: rgb(199, 198, 196);position: relative; left:20px" id="name1"></p></h1>
                </div></div></section>
            <br>
        <section style="padding-bottom: 150px;">
        <div class="col-lg-2"></div>
        <div style="float:left">
          <h3 style='position:relative;left:200px;color:white;white-space:nowrap' id="name"></h3><br>
          <h3 style="position:relative;left:200px;color:white;white-space:nowrap" id="email"></h3><br>
          <h3 style="position:relative;left:200px;color:white;white-space:nowrap" id="mobile"></h3><br></div>
          <!-- <h3 style="position:relative;left:200px;color:white">Password : &nbsp &nbsp<p id="pass"></p></h3><br></div>-->
        <div style="float:right"></div><img src="images/contact-in-person.png" style="position:relative;left:500px" height=200></div>     
        </section>

        <section style="padding-bottom: 10px;">
            <div class="row" style="padding-bottom: 10px;margin-top: 2%;">
                <div class="col-lg-2"></div>
                <div class="col-lg-2" style="background-color: rgb(31, 31, 31);padding-bottom: 7px;position: relative;left:70px" id="view">
                 <a> <h3 style="color: rgb(199, 198, 196);position: relative; left:17px">View bills</h3></a>
                </div>
            
                <div class="col-lg-2"></div>
                <div class="col-lg-2" style="background-color: rgb(31, 31, 31);padding-bottom: 7px;position: relative;left:70px">
                  <a href="addbill.php"><h3 style="color: rgb(199, 198, 196);position: relative; left:20px">Add bills</h3></a>
                </div></div>
            </section>

       
<section>
    <div class="row" class="container">
        <div class="col-lg-12" style="color:white; text-align: center;">This website basically aims for securing the ownership of the products by saving bills. You can save your bills in the form of image and also upload the picture of your product purchased. The data for the bill that is once saved can never be changed. You can change the profile data but you cannot change the data provided after saving the bill.</h5>
            <h5>Join us: <img src="images/download.jpg" width=30 height=30>&nbsp &nbsp <img src="images/twitter.png" width=30 height=30></div>
    </div>
</section>


    </body>
    </html>