<!DOCTYPE html>
<html lang="en">
<head>
  <title>Bootstrap Example</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/js/bootstrap.min.js"></script>
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
</head>

<body style="background-color: black;">

  <nav class="navbar navbar-inverse">
    <div class="container-fluid">
      
      <ul class="nav navbar-nav">
        <li class="active"><a href="ProfilePage.php">My Profile</a></li>
      </ul>
      <ul class="nav navbar-nav navbar-right">
        <li><a href="mailto: priyanshi.18bcs1068@abes.ac.in">Contact Us </a></li>
        <li>
          <div class="navbar-header">
            <a class="navbar-brand" href="index.php">Home Page</a>
          </div>
        </li>
      </ul>
    </div>
  </nav> 
  
<div class="container" style="text-align: center;">
  <div class="row" style="background-color: rgb(31, 31, 31);padding-bottom: 15px;">
    <div class="col-lg-5">
      <h2 style="float: right;color: cadetblue;width: 85%;background-image:linear-gradient(to right, rgb(31, 31, 31) , rgb(61, 61, 61));padding: 7px 1px;"><i class="fa fa-gear" style="font-size:42px;padding-right:5%;"></i>OWNERSHIP CHAIN</h2>
    </div>
    <div class="col-lg-7">
      <h2 style="float: right;color: cadetblue;font-size: 30px;margin-top: 30px;">Secure the ownership of your products</h2>
    </div>
  </div>
  <div class="row" style="padding-bottom: 15px;margin-top: 2%;">
    <div class="col-lg-4" style="background-color: rgb(31, 31, 31);padding-bottom: 7px;">
      <h2 style="color: rgb(199, 198, 196);">Welcome Sejal Jha</h2>
    </div>
  </div>
  <div class="row" style="padding-bottom: 15px;margin-top: 1%;">
    <table class="table table-bordered table-dark"  style="color:rgb(199, 198, 196);">
        <thead>
          <tr>
            <th scope="col">Sl no.</th>
            <th scope="col">Types of bills</th>
            <th scope="col">Amount Paid</th>
            <th scope="col">Image of Product Purchased</th>
            <th scope="col">Bill</th>
        </tr>
        </thead>
        <tbody>
          <tr>
            <th scope="row">1</th>
            <td>Electricity Bill</td>
            <td>Rs. 600</td>
            <td>view</td>
            <td>view</td>
          </tr>
          <tr>
            <th scope="row">2</th>
            <td>Wafer Bill</td>
            <td>Rs. 1000</td>
            <td>view</td>
            <td>view</td>
          </tr>
          <tr>
            <th scope="row">3</th>
            <td>Medical Bill</td>
            <td>Rs. 500</td>
            <td>view</td>
            <td>view</td>
          </tr>
          <tr>
            <th scope="row">4</th>
            <td>Shopping Bill</td>
            <td>Rs. 600</td>
            <td><a href="seeproduct.php">view</a></td>
            <td><a href="seebill.php">view</a></td>
          </tr>
        </tbody>
      </table>
  </div>
</div>
<div class="footer" style="text-align: center;position:fixed;bottom: 0;background-color: rgb(31, 31, 31);color: rgb(199, 198, 196)">
  <h5 style="padding: 10px 40px;padding-bottom: 0;">This website basically aims for securing the ownership of the products by saving bills. You can save your bills in the form of image and also upload the picture of your product purchased. The data for the bill that is once saved can never be changed. You can change the profile data but you cannot change the data provided after saving the bill.</h5>
  <h5>Join us: <img src="images/download.jpg" width=30 height=30>&nbsp &nbsp <img src="images/twitter.png" width=30 height=30></h5>
</div>
</body>
</html>
