<!DOCTYPE html>
<html>
<head>
	<title>How to Design Login & Registration Form Transition</title>
	<meta charset="UTF-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" type="text/css" href="cssfiles/style.css">
  <link href="https://fonts.googleapis.com/css?family=Nunito:400,600,700,800&display=swap" rel="stylesheet">
 
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
  <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.16.0/umd/popper.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.0/js/bootstrap.min.js"></script>
</head>
<body>
  <script src="jsfiles/smartcontract.js"></script>
 <script>
   $(document).ready(function(){
        $("#signin").click(function(){
          var semail = $("#signemail").val();
          var spass = $("#signpassword").val();
          if(typeof web3!='undefined'){
                var web3=new Web3(web3.currentProvider);
            }else{
               var web3=new Web3(new Web3.providers.HttpProvider("http://localhost:7545"));
            }
            web3.eth.defaultAccount=web3.eth.accounts[0];
            //alert(web3.eth.accounts[0]);
            var sc=web3.eth.contract(ABI);
            var tc=sc.at(address);
           // console.log(tc);
            var status = tc.login(semail,spass,{from: web3.eth.accounts[0], gas: 200000});
            console.log(status)
            if(status)
              window.location.href='ProfilePage.php';
            else
              alert("Wrong email or passsword");
            //alert("Name :"+user[0]+"\n Email :"+user[1]+"\nMobile :"+user[2]+"\nPassword :"+user[3]);
        });

        $("#signup").click(function(){
          var email = $("#email").val();
          var pass = $("#password").val();
          var mob = $("#mobile").val();
          var name = $("#name").val();
          if(typeof web3!='undefined'){
                var web3=new Web3(web3.currentProvider);
            }else{
               var web3=new Web3(new Web3.providers.HttpProvider("http://localhost:7545"));
            }
            web3.eth.defaultAccount=web3.eth.accounts[0];
            alert(web3.eth.accounts[0]);
            var sc=web3.eth.contract(ABI);
            var tc=sc.at(address);
            console.log(tc);
            tc.registerUser(name,email,mob,pass,{from: web3.eth.accounts[0], gas: 200000});
            alert("User joined Ownership Chain");
        });
  });

 </script>

  <div class="cont">
    <div class="form sign-in">
      <h2>Sign In</h2>
      <label>
        <span>Email Address</span>
        <input type="email" name="email" id="signemail">
      </label>
      <label>
        <span>Password</span>
        <input type="password" name="password" id="signpassword">
      </label>
    <a> <button class="submit" type="button" id="signin">Sign In</button></a>
      <p class="forgot-pass">Forgot Password ?</p>

      <div class="social-media">
        <ul>
          <li><img src="images/facebook.png"></li>
          <li><img src="images/twitter.png"></li>
          <li><img src="images/linkedin.png"></li>
          <li><img src="images/download.jpg"></li>
        </ul>
      </div>
    </div>

    <div class="sub-cont">
      <div class="img">
        <div class="img-text m-up">
          <h2>New here?</h2>
          <p>Sign up and discover great amount of new opportunities!</p>
        </div>
        <div class="img-text m-in">
          <h2>One of us?</h2>
          <p>If you already has an account, just sign in. We've missed you!</p>
        </div>
        <div class="img-btn">
          <span class="m-up">Sign Up</span>
         <a> <span class="m-in">Sign In</span>
        </div>
      </div>
      <div class="form sign-up" style="height: 500px;">
        <h2>Sign Up</h2>
        <form action="ProfilePage.php" method="post">
        <label>
          <span>Name</span>
          <input type="text" id="name" name="Name">
        </label>
        <label>
          <span>Email</span>
          <input type="email" id="email" name="Email">
        </label>
        <label>
          <span>Mobile</span>
          <input type="text" id="mobile" name="Mobile">
        </label>
        <label>
          <span>Password</span>
          <input type="password" id="password" name="Password">
        </label>
        <label>
          <span>Add Photo</span>
  <input type="file" id="img" name="img" accept="image/*">
        </label>
        <button type="button" class="submit" id="signup">Sign Up Now</button>
      </div>
      </form>
    </div>
  </div>
<script type="text/javascript" src="jsfiles/script.js"></script>
</body>
</html>