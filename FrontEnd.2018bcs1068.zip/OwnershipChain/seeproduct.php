<!DOCTYPE html>
<html>
<!-- Latest compiled and minified CSS -->
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.0/css/bootstrap.min.css">

<!-- jQuery library -->
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>

<!-- Popper JS -->
<script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.16.0/umd/popper.min.js"></script>

<!-- Latest compiled JavaScript -->
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.0/js/bootstrap.min.js"></script>

    <body style="background-color: black;">
        <header>
            <nav class="navbar navbar-expand-sm bg-dark navbar-dark">
              
                <!-- Links -->
                <ul class="navbar-nav">
                  <li class="nav-item">
                    <a class="nav-link" href="ProfilePage.php">My Profile</a>
                  </li>
                  <li class="nav-item">
                    <a class="nav-link" href="mailto: priyanshi.18bcs1068@abes.ac.in" style="position: relative; left:1100px">Contact us</a>
                  </li>

                  <li class="nav-item">
                    <a class="nav-link" href="index.php" style="position: relative; left:1200px">Home Screen</a>
                  </li>
                </ul>
              </nav>
              
        </header>
        <div class="container" style="background-color: black;">
            <div class="fluid-container" style="background-color: black;">
            <img src="images/Capture.PNG" width=100% style="position:relative; left:-30px;"></div>
        </div>



        <section style="padding-bottom: 15px;">
            <div class="row" style="padding-bottom: 20px;margin-top: 2%;">
                <div class="col-lg-1"></div>
                <div class="col-lg-3" style="background-color: rgb(31, 31, 31);padding-bottom: 7px;position: relative;left:50px">
                  <h1 style="color: rgb(199, 198, 196);position: relative; left:20px">Welcome Sejal Jha</h1>
                </div>
                <div class="col-lg-2"></div>
                <div class="col-lg-3" style="background-color: rgb(31, 31, 31);padding-bottom: 7px;position: relative;left:50px">
                    <h1 style="color: rgb(199, 198, 196);position: relative; left:20px">Products Purchased</h1>
                  </div>
              </div>
              <br>

        <section>
        <div class="row" style="padding-bottom: 20px;margin-top: 2%;">
            <div class="col-lg-1"></div>
            <div class="col-lg-4" style="background-color: rgb(31, 31, 31);padding-bottom: 150px;position: relative;left:50px">
                <h1 class="display-3" style="color:cornsilk"><b>Buying is a Profound Pleasure.</b></h1><br><br>
                <a href="images/product.jpg" download><button type="button" class="btn btn-primary btn-lg" style="position: relative; left:300px;">Download Image</button></a>
            </div>
            <div class="col-lg-1"></div>
            <div class="col-lg-5" style="padding-bottom: 20px;">
                <img src="images/product.jpg">
            </div>
        </section>
<br>
<section>
    <div class="row">
        <div class="col-lg-12" style="color:white; text-align: center;">This website basically aims for securing the ownership of the products by saving bills. You can save your bills in the form of image and also upload the picture of your product purchased. The data for the bill that is once saved can never be changed. You can change the profile data but you cannot change the data provided after saving the bill.</h5>
            <h5>Join us:<img src="images/download.jpg" width=30 height=30>&nbsp &nbsp <img src="images/twitter.png" width=30 height=30></div>
    </div>
</section>
    </body>
</html>